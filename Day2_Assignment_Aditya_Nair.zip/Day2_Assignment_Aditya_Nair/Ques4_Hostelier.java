package com.ct;

public class Ques4_Hostelier extends Ques4_Base {
	public void hostel_fees() {
		System.out.println("Hostel Fees Paid");
	}

}
