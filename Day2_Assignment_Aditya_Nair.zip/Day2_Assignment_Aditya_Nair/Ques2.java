package com.ct;

public class Ques2 {

	public static void main(String[] args) {
		//GlobalVariables obj = new GlobalVariables()
		Count obj1 = new Count();
		Count obj2 = new Count();
		Count obj3 = new Count();
		Count obj4 = new Count();
		System.out.println("count =" + obj4.a);
	}

}


class Count{
	static int a;
	Count()
	{
		a += 1;
	}
}