package com.ct;

public class Ques1_Base {
	public void on(){
		System.out.println("ON");
	}
	public void off() {
		System.out.println("OFF");
		
	}
	public void next() {
		System.out.println("Next Channel/slide");
	}

}
