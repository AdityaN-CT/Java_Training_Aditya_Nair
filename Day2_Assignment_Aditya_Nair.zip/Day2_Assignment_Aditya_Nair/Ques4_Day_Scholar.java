package com.ct;

public class Ques4_Day_Scholar extends Ques4_Base {
	public void commute_time() {
		System.out.println("The commute time for student is 2 hours");
	}
	

}
