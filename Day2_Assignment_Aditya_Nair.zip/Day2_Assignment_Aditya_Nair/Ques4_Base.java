package com.ct;

public class Ques4_Base {
	public void college_Timings(){
		System.out.println("9:00 - 16:00");
	}
	public void exam_timings() {
		System.out.println(" 11:00 - 13:00");
	}
}
