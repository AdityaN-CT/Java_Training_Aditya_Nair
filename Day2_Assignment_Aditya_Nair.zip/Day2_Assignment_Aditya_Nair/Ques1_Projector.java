package com.ct;

public class Ques1_Projector extends Ques1_Base {
	public void increase_brightness() {
		System.out.println("Increase Brightness");
	}
	
	public void decrease_brightness() {
		System.out.println("Increase Brightness");
	}
	

	
}
