package com.ct;

public class Ques1_TV extends Ques1_Base {
	public void volume_up() {
		System.out.println("Increase Volume");
	}
	public void volume_down() {
		System.out.println("Decrease Volume");
	}
	public void increase_brightness() {
		System.out.println("Increase Brightness");
	}
	
	public void decrease_brightness() {
		System.out.println("Increase Brightness");
	}
	

}
