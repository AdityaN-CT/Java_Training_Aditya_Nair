package com.ct;

public class Ques_3 {

	public static void main(String[] args) {
		Read_Only obj = new Read_Only(5);
		System.out.println("number = " + obj.getRead_only_var());
		

	}

}

class Read_Only{
	private int read_only_var = 10;
	
	Read_Only(int number){
		this.read_only_var = number;
	}

	public int getRead_only_var() {
		return read_only_var;
	}

}