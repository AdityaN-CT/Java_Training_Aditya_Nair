package com.ct;

public class Ques1_Radio extends Ques1_Base {
	public void volume_up() {
		System.out.println("Increase Volume");
	}
	public void volume_down() {
		System.out.println("Decrease Volume");
	}
	

}
